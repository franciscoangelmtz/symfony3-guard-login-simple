<?php

/* security/login.html.twig */
class __TwigTemplate_e20a76f497929fb49298f03c5f8256a9a2380b307b185e6c06dc8751b802849f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f93c9f50228bf412303fcf71728e796c9fb265575e581990af307f4965fb269e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f93c9f50228bf412303fcf71728e796c9fb265575e581990af307f4965fb269e->enter($__internal_f93c9f50228bf412303fcf71728e796c9fb265575e581990af307f4965fb269e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_f82c5b6216d13e9cffae838fb62d7c7c98722b5f1bc564b8b5162b0f57df9d9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f82c5b6216d13e9cffae838fb62d7c7c98722b5f1bc564b8b5162b0f57df9d9d->enter($__internal_f82c5b6216d13e9cffae838fb62d7c7c98722b5f1bc564b8b5162b0f57df9d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f93c9f50228bf412303fcf71728e796c9fb265575e581990af307f4965fb269e->leave($__internal_f93c9f50228bf412303fcf71728e796c9fb265575e581990af307f4965fb269e_prof);

        
        $__internal_f82c5b6216d13e9cffae838fb62d7c7c98722b5f1bc564b8b5162b0f57df9d9d->leave($__internal_f82c5b6216d13e9cffae838fb62d7c7c98722b5f1bc564b8b5162b0f57df9d9d_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_acdf3ad0b6212777f5480e2674a43e38e789e233b214830cffb3c5debd8f485e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acdf3ad0b6212777f5480e2674a43e38e789e233b214830cffb3c5debd8f485e->enter($__internal_acdf3ad0b6212777f5480e2674a43e38e789e233b214830cffb3c5debd8f485e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_eaa75f2fc7a264fe6aafcfba1c13a81de745214bde614087af1a255ef3fdc3cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eaa75f2fc7a264fe6aafcfba1c13a81de745214bde614087af1a255ef3fdc3cc->enter($__internal_eaa75f2fc7a264fe6aafcfba1c13a81de745214bde614087af1a255ef3fdc3cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-8 col-md-offset-2\">
            <div class=\"panel panel-default\">
                <div class=\"panel-heading\">Login</div>
                <div class=\"panel-body\">
                    <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login_check");
        echo "\">
                        ";
        // line 13
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 14
            echo "                            <div class=\"alert alert-danger\">
                                ";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array())), "html", null, true);
            echo "
                            </div>
                        ";
        }
        // line 18
        echo "
                        <div class=\"form-group\">
                            <label for=\"email\" class=\"col-md-4 control-label\">E-Mail Address</label>

                            <div class=\"col-md-6\">
                                <input id=\"email\" type=\"email\" class=\"form-control\" name=\"_email\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\">
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <label for=\"password\" class=\"col-md-4 control-label\">Password</label>

                            <div class=\"col-md-6\">
                                <input id=\"password\" type=\"password\" class=\"form-control\" name=\"_password\">
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-md-6 col-md-offset-4\">
                                <button type=\"submit\" class=\"btn btn-primary\">
                                    <i class=\"fa fa-btn fa-sign-in\"></i> Login
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_eaa75f2fc7a264fe6aafcfba1c13a81de745214bde614087af1a255ef3fdc3cc->leave($__internal_eaa75f2fc7a264fe6aafcfba1c13a81de745214bde614087af1a255ef3fdc3cc_prof);

        
        $__internal_acdf3ad0b6212777f5480e2674a43e38e789e233b214830cffb3c5debd8f485e->leave($__internal_acdf3ad0b6212777f5480e2674a43e38e789e233b214830cffb3c5debd8f485e_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 23,  72 => 18,  66 => 15,  63 => 14,  61 => 13,  57 => 12,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}



{% block body %}
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-8 col-md-offset-2\">
            <div class=\"panel panel-default\">
                <div class=\"panel-heading\">Login</div>
                <div class=\"panel-body\">
                    <form class=\"form-horizontal\" role=\"form\" method=\"POST\" action=\"{{ path('security_login_check') }}\">
                        {% if error %}
                            <div class=\"alert alert-danger\">
                                {{ error.messageKey|trans(error.messageData) }}
                            </div>
                        {% endif %}

                        <div class=\"form-group\">
                            <label for=\"email\" class=\"col-md-4 control-label\">E-Mail Address</label>

                            <div class=\"col-md-6\">
                                <input id=\"email\" type=\"email\" class=\"form-control\" name=\"_email\" value=\"{{ last_username }}\">
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <label for=\"password\" class=\"col-md-4 control-label\">Password</label>

                            <div class=\"col-md-6\">
                                <input id=\"password\" type=\"password\" class=\"form-control\" name=\"_password\">
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-md-6 col-md-offset-4\">
                                <button type=\"submit\" class=\"btn btn-primary\">
                                    <i class=\"fa fa-btn fa-sign-in\"></i> Login
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
", "security/login.html.twig", "C:\\xampp\\htdocs\\net\\app\\Resources\\views\\security\\login.html.twig");
    }
}
