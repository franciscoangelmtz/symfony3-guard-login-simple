<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0fd258d5cd90e6569d1ab61f7a8b5064101977573920a7e0c68993aed9a371c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3596ac10740b99e80766c1bcaa224aa39adc921ab740c6ddefa19f52ec564f96 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3596ac10740b99e80766c1bcaa224aa39adc921ab740c6ddefa19f52ec564f96->enter($__internal_3596ac10740b99e80766c1bcaa224aa39adc921ab740c6ddefa19f52ec564f96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_126d4917f83c6629faa8a0953a5576f4fedf48adbc67e9babf94b8b931674d1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_126d4917f83c6629faa8a0953a5576f4fedf48adbc67e9babf94b8b931674d1a->enter($__internal_126d4917f83c6629faa8a0953a5576f4fedf48adbc67e9babf94b8b931674d1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3596ac10740b99e80766c1bcaa224aa39adc921ab740c6ddefa19f52ec564f96->leave($__internal_3596ac10740b99e80766c1bcaa224aa39adc921ab740c6ddefa19f52ec564f96_prof);

        
        $__internal_126d4917f83c6629faa8a0953a5576f4fedf48adbc67e9babf94b8b931674d1a->leave($__internal_126d4917f83c6629faa8a0953a5576f4fedf48adbc67e9babf94b8b931674d1a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_36f8397c5021df5d399af758b97b4086780f63bd1ca211f6751ef0fe45beb92b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36f8397c5021df5d399af758b97b4086780f63bd1ca211f6751ef0fe45beb92b->enter($__internal_36f8397c5021df5d399af758b97b4086780f63bd1ca211f6751ef0fe45beb92b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_6bf123934d83db19fe6993c615181bf13226d804e663f8dda092eb7383f7f970 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6bf123934d83db19fe6993c615181bf13226d804e663f8dda092eb7383f7f970->enter($__internal_6bf123934d83db19fe6993c615181bf13226d804e663f8dda092eb7383f7f970_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_6bf123934d83db19fe6993c615181bf13226d804e663f8dda092eb7383f7f970->leave($__internal_6bf123934d83db19fe6993c615181bf13226d804e663f8dda092eb7383f7f970_prof);

        
        $__internal_36f8397c5021df5d399af758b97b4086780f63bd1ca211f6751ef0fe45beb92b->leave($__internal_36f8397c5021df5d399af758b97b4086780f63bd1ca211f6751ef0fe45beb92b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_8bd9a7a0ae474652f338b901379cc435b2a771409609f7f9cbdb9ed94bcd19fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bd9a7a0ae474652f338b901379cc435b2a771409609f7f9cbdb9ed94bcd19fb->enter($__internal_8bd9a7a0ae474652f338b901379cc435b2a771409609f7f9cbdb9ed94bcd19fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a1220f1ba2c44d97cf5e6ddc6c38b6289336a9318cbfc985ab8050cb3bce217f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1220f1ba2c44d97cf5e6ddc6c38b6289336a9318cbfc985ab8050cb3bce217f->enter($__internal_a1220f1ba2c44d97cf5e6ddc6c38b6289336a9318cbfc985ab8050cb3bce217f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a1220f1ba2c44d97cf5e6ddc6c38b6289336a9318cbfc985ab8050cb3bce217f->leave($__internal_a1220f1ba2c44d97cf5e6ddc6c38b6289336a9318cbfc985ab8050cb3bce217f_prof);

        
        $__internal_8bd9a7a0ae474652f338b901379cc435b2a771409609f7f9cbdb9ed94bcd19fb->leave($__internal_8bd9a7a0ae474652f338b901379cc435b2a771409609f7f9cbdb9ed94bcd19fb_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7f536d49353297965d5bf74999ffd27c92f92467f95c76e87991a57a53e34c38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f536d49353297965d5bf74999ffd27c92f92467f95c76e87991a57a53e34c38->enter($__internal_7f536d49353297965d5bf74999ffd27c92f92467f95c76e87991a57a53e34c38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_93eb65ed11f29230c877dc5f60331cb2416e8e0fd873d21e02798ed8aec5b5ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93eb65ed11f29230c877dc5f60331cb2416e8e0fd873d21e02798ed8aec5b5ba->enter($__internal_93eb65ed11f29230c877dc5f60331cb2416e8e0fd873d21e02798ed8aec5b5ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_93eb65ed11f29230c877dc5f60331cb2416e8e0fd873d21e02798ed8aec5b5ba->leave($__internal_93eb65ed11f29230c877dc5f60331cb2416e8e0fd873d21e02798ed8aec5b5ba_prof);

        
        $__internal_7f536d49353297965d5bf74999ffd27c92f92467f95c76e87991a57a53e34c38->leave($__internal_7f536d49353297965d5bf74999ffd27c92f92467f95c76e87991a57a53e34c38_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\net\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
