<?php

/* default/index.html.twig */
class __TwigTemplate_a694d06dfc2713ce2ad0d33d8cb0f32ee1d79d8a1e2d37812dfc811d8ff907ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f54152aa6a6d85872874a960311bab33c110705fc150e2bfad99b30163f3ab1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f54152aa6a6d85872874a960311bab33c110705fc150e2bfad99b30163f3ab1b->enter($__internal_f54152aa6a6d85872874a960311bab33c110705fc150e2bfad99b30163f3ab1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_51ca79bd1f84c2e38b20163de2091d2920ee49feb270de2951e1bbf64dc4ac6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51ca79bd1f84c2e38b20163de2091d2920ee49feb270de2951e1bbf64dc4ac6b->enter($__internal_51ca79bd1f84c2e38b20163de2091d2920ee49feb270de2951e1bbf64dc4ac6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f54152aa6a6d85872874a960311bab33c110705fc150e2bfad99b30163f3ab1b->leave($__internal_f54152aa6a6d85872874a960311bab33c110705fc150e2bfad99b30163f3ab1b_prof);

        
        $__internal_51ca79bd1f84c2e38b20163de2091d2920ee49feb270de2951e1bbf64dc4ac6b->leave($__internal_51ca79bd1f84c2e38b20163de2091d2920ee49feb270de2951e1bbf64dc4ac6b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3cefa9088536682a3a5ed37058974cbc04605e62337807ebb0be57440d819372 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3cefa9088536682a3a5ed37058974cbc04605e62337807ebb0be57440d819372->enter($__internal_3cefa9088536682a3a5ed37058974cbc04605e62337807ebb0be57440d819372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bc834cf4ae42ae86a39965f0c28653ce69b716dc97cd1ab5ff6b90782f6d2a64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc834cf4ae42ae86a39965f0c28653ce69b716dc97cd1ab5ff6b90782f6d2a64->enter($__internal_bc834cf4ae42ae86a39965f0c28653ce69b716dc97cd1ab5ff6b90782f6d2a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "


  
    <div class=\"container theme-showcase\" role=\"main\">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class=\"jumbotron\">
        <h1>Welcome to Net</h1>
        <p>This is a template showcasing the optional theme stylesheet included in Bootstrap. Use it as a starting point to create something more unique by building on or modifying it.</p>
      </div>



     


    </div> <!-- /container -->



";
        
        $__internal_bc834cf4ae42ae86a39965f0c28653ce69b716dc97cd1ab5ff6b90782f6d2a64->leave($__internal_bc834cf4ae42ae86a39965f0c28653ce69b716dc97cd1ab5ff6b90782f6d2a64_prof);

        
        $__internal_3cefa9088536682a3a5ed37058974cbc04605e62337807ebb0be57440d819372->leave($__internal_3cefa9088536682a3a5ed37058974cbc04605e62337807ebb0be57440d819372_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}



  
    <div class=\"container theme-showcase\" role=\"main\">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class=\"jumbotron\">
        <h1>Welcome to Net</h1>
        <p>This is a template showcasing the optional theme stylesheet included in Bootstrap. Use it as a starting point to create something more unique by building on or modifying it.</p>
      </div>



     


    </div> <!-- /container -->



{% endblock %}

", "default/index.html.twig", "C:\\xampp\\htdocs\\net\\app\\Resources\\views\\default\\index.html.twig");
    }
}
