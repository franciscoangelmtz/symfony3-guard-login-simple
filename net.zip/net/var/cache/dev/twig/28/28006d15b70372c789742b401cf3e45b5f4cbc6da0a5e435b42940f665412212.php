<?php

/* security/register.html.twig */
class __TwigTemplate_35475a252b3c9abbeb5e75e83aad6e878f22827dd5d0ee6f0cb69f560a530733 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/register.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1a96bd79679f062d0983437ccb36cfa0a1b509c55d02f1e8ce13ce593436fdb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1a96bd79679f062d0983437ccb36cfa0a1b509c55d02f1e8ce13ce593436fdb->enter($__internal_a1a96bd79679f062d0983437ccb36cfa0a1b509c55d02f1e8ce13ce593436fdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/register.html.twig"));

        $__internal_60fff171199c749367bfaa06e17efe230dbeafe85771a056ecf1cf875f547c87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60fff171199c749367bfaa06e17efe230dbeafe85771a056ecf1cf875f547c87->enter($__internal_60fff171199c749367bfaa06e17efe230dbeafe85771a056ecf1cf875f547c87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a1a96bd79679f062d0983437ccb36cfa0a1b509c55d02f1e8ce13ce593436fdb->leave($__internal_a1a96bd79679f062d0983437ccb36cfa0a1b509c55d02f1e8ce13ce593436fdb_prof);

        
        $__internal_60fff171199c749367bfaa06e17efe230dbeafe85771a056ecf1cf875f547c87->leave($__internal_60fff171199c749367bfaa06e17efe230dbeafe85771a056ecf1cf875f547c87_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_b983f5701f56870638fcad88b15ef20ba2a5b5d3bb808d34974d272757c85446 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b983f5701f56870638fcad88b15ef20ba2a5b5d3bb808d34974d272757c85446->enter($__internal_b983f5701f56870638fcad88b15ef20ba2a5b5d3bb808d34974d272757c85446_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d0d97bdb9125eade472e022da5e96d51aa6d947ea54c4a4fd71d8d449e6360a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0d97bdb9125eade472e022da5e96d51aa6d947ea54c4a4fd71d8d449e6360a5->enter($__internal_d0d97bdb9125eade472e022da5e96d51aa6d947ea54c4a4fd71d8d449e6360a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-md-8 col-md-offset-2\">
    <h1>Registro</h1>
        <div class=\"panel panel-default\">
          <div class=\"panel-heading\">Register</div>
          <div class=\"panel-body\">
            ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                  ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                ";
        // line 34
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'row', array("attr" => array("class" => "form-control")));
        echo "
              </div>
            </div>

            <div class=\"form-group\">
                <div class=\"col-md-8 col-md-offset-4\" style=\"margin-top:5px;\">
                    <button type=\"submit\" class=\"btn btn-primary\">
                        <i class=\"fa fa-btn fa-user\"></i> Register
                    </button>
                </div>
            </div>
            ";
        // line 45
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
          </div>
        </div>
    </div>
  </div>
</div>
";
        
        $__internal_d0d97bdb9125eade472e022da5e96d51aa6d947ea54c4a4fd71d8d449e6360a5->leave($__internal_d0d97bdb9125eade472e022da5e96d51aa6d947ea54c4a4fd71d8d449e6360a5_prof);

        
        $__internal_b983f5701f56870638fcad88b15ef20ba2a5b5d3bb808d34974d272757c85446->leave($__internal_b983f5701f56870638fcad88b15ef20ba2a5b5d3bb808d34974d272757c85446_prof);

    }

    public function getTemplateName()
    {
        return "security/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 45,  91 => 34,  82 => 28,  73 => 22,  64 => 16,  58 => 13,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}



{% block body %}
<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-md-8 col-md-offset-2\">
    <h1>Registro</h1>
        <div class=\"panel panel-default\">
          <div class=\"panel-heading\">Register</div>
          <div class=\"panel-body\">
            {{ form_start(form) }}
            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                  {{ form_row(form.name, {'attr': {'class': 'form-control'}}) }}
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                {{ form_row(form.email, {'attr': {'class': 'form-control'}}) }}
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                {{ form_row(form.plainPassword.first, {'attr': {'class': 'form-control'}}) }}
                </div>
            </div>

            <div class=\"form_group\">
                <div class=\"col-md-8 col-md-offset-2\">
                {{ form_row(form.plainPassword.second, {'attr': {'class': 'form-control'}}) }}
              </div>
            </div>

            <div class=\"form-group\">
                <div class=\"col-md-8 col-md-offset-4\" style=\"margin-top:5px;\">
                    <button type=\"submit\" class=\"btn btn-primary\">
                        <i class=\"fa fa-btn fa-user\"></i> Register
                    </button>
                </div>
            </div>
            {{ form_end(form) }}
          </div>
        </div>
    </div>
  </div>
</div>
{% endblock %}", "security/register.html.twig", "C:\\xampp\\htdocs\\net\\app\\Resources\\views\\security\\register.html.twig");
    }
}
