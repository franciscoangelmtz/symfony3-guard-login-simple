<?php

/* datos/index.html.twig */
class __TwigTemplate_82321e1b43c71a34934d71f519422d6a65ceb428b9f28b287c9e79008a7fed57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "datos/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f66b842d993a346e140638696b216a679f9b0023b3498f882b21689f1ebb310 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f66b842d993a346e140638696b216a679f9b0023b3498f882b21689f1ebb310->enter($__internal_6f66b842d993a346e140638696b216a679f9b0023b3498f882b21689f1ebb310_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "datos/index.html.twig"));

        $__internal_e7aeb372eb1061e06c719746d157eb7490ca8bc4daa1386296acfed300c3ee77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7aeb372eb1061e06c719746d157eb7490ca8bc4daa1386296acfed300c3ee77->enter($__internal_e7aeb372eb1061e06c719746d157eb7490ca8bc4daa1386296acfed300c3ee77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "datos/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f66b842d993a346e140638696b216a679f9b0023b3498f882b21689f1ebb310->leave($__internal_6f66b842d993a346e140638696b216a679f9b0023b3498f882b21689f1ebb310_prof);

        
        $__internal_e7aeb372eb1061e06c719746d157eb7490ca8bc4daa1386296acfed300c3ee77->leave($__internal_e7aeb372eb1061e06c719746d157eb7490ca8bc4daa1386296acfed300c3ee77_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_2f5f7e381350a5fbfecf567ef3570d045bfb3a4a0b368024062c0efbbe6dbc4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f5f7e381350a5fbfecf567ef3570d045bfb3a4a0b368024062c0efbbe6dbc4a->enter($__internal_2f5f7e381350a5fbfecf567ef3570d045bfb3a4a0b368024062c0efbbe6dbc4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a5af96e00d959beeb6dcd8056dc5c21d5c672618bdb1d5c7f4e66a47e10e9df8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5af96e00d959beeb6dcd8056dc5c21d5c672618bdb1d5c7f4e66a47e10e9df8->enter($__internal_a5af96e00d959beeb6dcd8056dc5c21d5c672618bdb1d5c7f4e66a47e10e9df8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-10 col-md-offset-1\">
        <h1>Listado</h1>
            <div class=\"panel panel-success\">
                <div class=\"panel-heading\">List of Game of Thrones Characters</div>

                ";
        // line 13
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) != null)) {
            // line 14
            echo "                  <table class=\"table\">
                      <tr>
                          <th>Character</th>
                          <th>Real Name</th>
                      </tr>

                      ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["character"]) ? $context["character"] : $this->getContext($context, "character")));
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 21
                echo "                        <tr>
                          <td>";
                // line 22
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "</td><td>";
                echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                echo "</td>
                        </tr>
                      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "                  </table>
                ";
        }
        // line 27
        echo "

            </div>

            ";
        // line 31
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) == null)) {
            // line 32
            echo "              <a href=\"/login\" class=\"btn btn-info\"> You need to login to see the list 😜😜 >></a>
            ";
        }
        // line 34
        echo "        </div>
    </div>
</div>
";
        
        $__internal_a5af96e00d959beeb6dcd8056dc5c21d5c672618bdb1d5c7f4e66a47e10e9df8->leave($__internal_a5af96e00d959beeb6dcd8056dc5c21d5c672618bdb1d5c7f4e66a47e10e9df8_prof);

        
        $__internal_2f5f7e381350a5fbfecf567ef3570d045bfb3a4a0b368024062c0efbbe6dbc4a->leave($__internal_2f5f7e381350a5fbfecf567ef3570d045bfb3a4a0b368024062c0efbbe6dbc4a_prof);

    }

    public function getTemplateName()
    {
        return "datos/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 34,  98 => 32,  96 => 31,  90 => 27,  86 => 25,  75 => 22,  72 => 21,  68 => 20,  60 => 14,  58 => 13,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}



{% block body %}
<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-10 col-md-offset-1\">
        <h1>Listado</h1>
            <div class=\"panel panel-success\">
                <div class=\"panel-heading\">List of Game of Thrones Characters</div>

                {% if app.user != null %}
                  <table class=\"table\">
                      <tr>
                          <th>Character</th>
                          <th>Real Name</th>
                      </tr>

                      {% for key, item in character %}
                        <tr>
                          <td>{{ key }}</td><td>{{ item }}</td>
                        </tr>
                      {% endfor %}
                  </table>
                {% endif %}


            </div>

            {% if app.user == null %}
              <a href=\"/login\" class=\"btn btn-info\"> You need to login to see the list 😜😜 >></a>
            {% endif %}
        </div>
    </div>
</div>
{% endblock %}", "datos/index.html.twig", "C:\\xampp\\htdocs\\net\\app\\Resources\\views\\datos\\index.html.twig");
    }
}
