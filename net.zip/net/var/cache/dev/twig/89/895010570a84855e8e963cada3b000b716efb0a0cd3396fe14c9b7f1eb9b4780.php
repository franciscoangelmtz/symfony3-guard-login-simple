<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_d0ea04b0681df5be4f4372891dbf57cd265f736c45c771d50e480f083206011b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0cb6f1c657ab617d336ab1e401c2468f21cbb77f35cbb0b59754c94b726e3715 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0cb6f1c657ab617d336ab1e401c2468f21cbb77f35cbb0b59754c94b726e3715->enter($__internal_0cb6f1c657ab617d336ab1e401c2468f21cbb77f35cbb0b59754c94b726e3715_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_6fd9578cc6407307ec09b2db113d321926184ddc24e20c98fee1d4a052a3e535 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fd9578cc6407307ec09b2db113d321926184ddc24e20c98fee1d4a052a3e535->enter($__internal_6fd9578cc6407307ec09b2db113d321926184ddc24e20c98fee1d4a052a3e535_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0cb6f1c657ab617d336ab1e401c2468f21cbb77f35cbb0b59754c94b726e3715->leave($__internal_0cb6f1c657ab617d336ab1e401c2468f21cbb77f35cbb0b59754c94b726e3715_prof);

        
        $__internal_6fd9578cc6407307ec09b2db113d321926184ddc24e20c98fee1d4a052a3e535->leave($__internal_6fd9578cc6407307ec09b2db113d321926184ddc24e20c98fee1d4a052a3e535_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_fc4fa37c2b323f03350ebfca0ca8cbda99517ae82ad545327d73a4614fe45ad1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc4fa37c2b323f03350ebfca0ca8cbda99517ae82ad545327d73a4614fe45ad1->enter($__internal_fc4fa37c2b323f03350ebfca0ca8cbda99517ae82ad545327d73a4614fe45ad1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ac751a5a4427ae7cabc86e272ca99db493ef4c46dd2defe49459b6e8e5a37860 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac751a5a4427ae7cabc86e272ca99db493ef4c46dd2defe49459b6e8e5a37860->enter($__internal_ac751a5a4427ae7cabc86e272ca99db493ef4c46dd2defe49459b6e8e5a37860_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_ac751a5a4427ae7cabc86e272ca99db493ef4c46dd2defe49459b6e8e5a37860->leave($__internal_ac751a5a4427ae7cabc86e272ca99db493ef4c46dd2defe49459b6e8e5a37860_prof);

        
        $__internal_fc4fa37c2b323f03350ebfca0ca8cbda99517ae82ad545327d73a4614fe45ad1->leave($__internal_fc4fa37c2b323f03350ebfca0ca8cbda99517ae82ad545327d73a4614fe45ad1_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3f3d79e338b4fddd3b85d77e0daad38df95a7c273b8c03e31609b8f477f8262f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f3d79e338b4fddd3b85d77e0daad38df95a7c273b8c03e31609b8f477f8262f->enter($__internal_3f3d79e338b4fddd3b85d77e0daad38df95a7c273b8c03e31609b8f477f8262f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_2a32a33fa252883f7251a2401708a62828b077c3804cff432a7d8bc1e3f039fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a32a33fa252883f7251a2401708a62828b077c3804cff432a7d8bc1e3f039fd->enter($__internal_2a32a33fa252883f7251a2401708a62828b077c3804cff432a7d8bc1e3f039fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_2a32a33fa252883f7251a2401708a62828b077c3804cff432a7d8bc1e3f039fd->leave($__internal_2a32a33fa252883f7251a2401708a62828b077c3804cff432a7d8bc1e3f039fd_prof);

        
        $__internal_3f3d79e338b4fddd3b85d77e0daad38df95a7c273b8c03e31609b8f477f8262f->leave($__internal_3f3d79e338b4fddd3b85d77e0daad38df95a7c273b8c03e31609b8f477f8262f_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_bc6081d8d6c614c0da9729696f6af4fa682c8ad39cb59ad8c5b121f5d3c87aef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc6081d8d6c614c0da9729696f6af4fa682c8ad39cb59ad8c5b121f5d3c87aef->enter($__internal_bc6081d8d6c614c0da9729696f6af4fa682c8ad39cb59ad8c5b121f5d3c87aef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_b3f64942aa11965c2302063219c0120a3dbc32a7152d2706f7eb78b1181b6db1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3f64942aa11965c2302063219c0120a3dbc32a7152d2706f7eb78b1181b6db1->enter($__internal_b3f64942aa11965c2302063219c0120a3dbc32a7152d2706f7eb78b1181b6db1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_b3f64942aa11965c2302063219c0120a3dbc32a7152d2706f7eb78b1181b6db1->leave($__internal_b3f64942aa11965c2302063219c0120a3dbc32a7152d2706f7eb78b1181b6db1_prof);

        
        $__internal_bc6081d8d6c614c0da9729696f6af4fa682c8ad39cb59ad8c5b121f5d3c87aef->leave($__internal_bc6081d8d6c614c0da9729696f6af4fa682c8ad39cb59ad8c5b121f5d3c87aef_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\net\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
